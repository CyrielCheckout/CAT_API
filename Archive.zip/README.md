# Install

Open folder and npm -i

## Run 

npm run dev  
